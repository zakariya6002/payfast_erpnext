# payfast_integration/payment_gateway/__init__.py
from . import payfast
